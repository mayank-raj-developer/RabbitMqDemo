package com.receive.receive;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReceiveApplication {

	public static void main(String[] args) {
		SpringApplication.run(ReceiveApplication.class, args);
	}

}
